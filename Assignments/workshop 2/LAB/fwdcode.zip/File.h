/*WORKSHOP -2
NAME: Prabhdeep Kaur
SENECA EMAIL: prabhdeep-kaur4@myseneca.ca
STUDENT ID: 145698221
DATE: September 16,2023
I have done all the coding by myself and only copied the code that
my professor provided to complete my workshops and assignments.
*/
#ifndef SDDS_FILE_H_
#define SDDS_FILE_H_
namespace sdds {
	bool openFile(const char filename[]);
	void closeFile();
	int noOfRecords();
	// TODO: Declare overloaded read function prototypes
	bool read(int& employeeNum);
	bool read(double& salary);
	bool read(char*& employeeName);
}

#endif // !SDDS_FILE_H_