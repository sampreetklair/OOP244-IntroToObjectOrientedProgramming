/*WORKSHOP -2
NAME: Prabhdeep Kaur
SENECA EMAIL: prabhdeep-kaur4@myseneca.ca
STUDENT ID: 145698221
DATE: September 16,2023
I have done all the coding by myself and only copied the code that
my professor provided to complete my workshops and assignments.
*/
#include "Employee.h"
using namespace sdds;
int main() {
    if (load()) {
        display();
    }
    deallocateMemory();
    return 0;
}