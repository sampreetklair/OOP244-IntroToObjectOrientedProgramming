# Workshop 9: Function Templates

## Learning
- code function templates
- implement calls to function templates
