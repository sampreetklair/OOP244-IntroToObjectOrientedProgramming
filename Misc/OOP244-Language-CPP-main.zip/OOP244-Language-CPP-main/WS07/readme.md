# Workshop 7: Derived Classes & Custom I/O Operators

## Learning
- inherit a derived class from a base class
- shadow a base class member function with a derived class member function
- access a shadowed member function that is defined in a base class
- utilize custom input/output operators with these classes

