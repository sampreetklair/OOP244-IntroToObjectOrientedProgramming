# Workshop 4 - Constructors Destructors and Current object

## Learning

- define a default constructor
- define custom constructors with different number of arguments
- define a Destructor to prevent memory leaks.
- Use the reference of the current object 
- describe to your instructor what you have learned in completing this workshop
