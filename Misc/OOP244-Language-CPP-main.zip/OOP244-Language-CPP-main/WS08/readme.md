# Workshop 8: Virtual functions and Abstract base classes

## Learning
- define pure virtual functions
- create abstract base classes
- implement behaviour using virtual functions
- explain the difference between an abstract base class and a concrete class

