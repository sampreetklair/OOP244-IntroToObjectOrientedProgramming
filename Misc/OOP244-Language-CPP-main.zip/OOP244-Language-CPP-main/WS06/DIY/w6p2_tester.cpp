// Workshop 6-diy:
// Version: 0.9
// Date: 2021/02/20
// Author: Fardad Soleimanloo
// Description:
// This file tests the diy section of your workshop
/////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include <string>
#include "Stats.h"
using namespace sdds;
using namespace std;

void twentyNumbers(Stats T);
void badIndex(const Stats& T);
void Copy(const string& dest, const string& source);
void Dump(const string& filename);

int main() {
  Copy("numLtl.csv", "numbersLtlOriginal.csv");
  Copy("numbers.csv", "numbersOriginal.csv");
  Stats L(10, 7, 0);
  Stats S("numLtl.csv"), Empty, BadFilename("badFilename");
  cout << "Type numbers.csv and hit <ENTER>" << endl;
  cout << "Enter the data file name: ";
  cin >> L;
  cout << L << endl;
  cout << S << endl;
  twentyNumbers(L); 
  twentyNumbers(S);
  cout << "Total of " << L.size() << " numbers in " << L.name() << endl;
  L[1000] = 11111.11;

  //TODO: below!!!
  L.occurrence(-12345.0, 31342.55); 
  L.sort(true);

  cout << "Sorted Ascending: " << endl;
  L.occurrence(-12345.0, 31342.55);
  L.sort(false);
  cout << "Sorted Descending: " << endl;
  L.occurrence(-12345.0, 31342.55);
  L = S; 
  cout << L << endl;
  cout << "============================================================" << endl;
  Dump("numbers.csv");
  Dump("numLtl.csv");
  Dump("C_numbers.csv");
  Dump("C_numLtl.csv");
  cout << "Empty object tests: " << endl;
  cout << "*" << Empty << BadFilename << "*" << endl;
  cout << Empty[10] << endl; 
  badIndex(Empty);
  Empty.sort(true);
  Empty.occurrence(1, 2);
  cout << Empty.size() << endl;
  return 0;
}

void twentyNumbers(Stats T) {
  if (T) {
    cout << ">>> 20 numbers of : " << T.name() << endl;
    cout.setf(ios::fixed);
    cout.precision(1);
    for (unsigned i = 0; i < 200; i += 10) {
      cout << "T[" << i << "]: " << T[i] << endl;
    }
    cout.unsetf(ios::fixed);
  }
  else {
    cout << "Nothing to print!" << endl;
  }
  cout << endl << "-------------------------------------------------------------" << endl;
}

void Dump(const string& filename) {
  cout << "DUMP---------------------------------------------------------" << endl;
  cout << ">>>" << filename << "<<<" << endl;
  ifstream fin(filename.c_str());
  int i = 0;
  char ch;
  while (fin.get(ch)) {
    if (i++ % 80 == 0) cout << endl;
    cout << ch;
  }
  cout << endl << "-------------------------------------------------------------" << endl;
}

void Copy(const string& dest, const string& source) {
  ifstream fin(source.c_str());
  ofstream fout(dest.c_str());
  char ch;
  while (fin.get(ch)) fout << ch;
}

void badIndex(const Stats& T) {
  cout << T[10] << endl;
}



/*
Create a module called Stats that can represent a file on the hard disk containing comma-separated numbers.

This module should be able to load the numbers and perform the following tasks.

A Stats object should be able to display the numbers in a tabular format on ostream in a specified number of columns, column width and precision.

A Stats object should be able to display the numbers that fall within a specific range and the number of their occurrence.

A Stats object should be able to sort the numbers in an ascending or descending order.

Copying a Stats object should be done safely and doing so it should also copy the data file on the hard disk.

The new file name should be the same as the original file with an added "C_" prefix.

Assigning a Stats object to another should be done safely and the content of the target file should also be overwritten by the source file.

A Stats object should also make the numbers available to the user program by indexing like an array.

A Stats object should be able to receive the data file name from the istream and load the data from the file on the hard drive.
*/