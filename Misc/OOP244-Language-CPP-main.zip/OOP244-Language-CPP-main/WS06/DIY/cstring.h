//==============================================
// Name:           Jungjoo Kim
// Student Number: 162 641 195
// Email:          jkim594@myseneca.ca
// Section:        NCC
// Workshop:       Workshop6_DIY
//==============================================
// cstring.h

#ifndef SDDS_CSTRING_H_
#define SDDS_CSTRING_H_
namespace sdds {
  int strLen(const char* s);
  void strCpy(char* des, const char* src);
  void strCat(char* des, const char* src);
}
#endif // !SDDS_CSTRING_H_
