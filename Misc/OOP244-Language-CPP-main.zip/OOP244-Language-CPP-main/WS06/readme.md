# Workshop 6: Classes and resources, IO operators

## Learning
- define and create copy constructors
- define and create copy assignment 
- Prevent copying and assignment in a class
- Overload insertion operator so the class can be printed using ostream
- Overload extraction operator so the class can be read using istream
- Do simple file IO using ifstream and ofstream
- use the C++ string class to extract an unknown number of characters from the input.
