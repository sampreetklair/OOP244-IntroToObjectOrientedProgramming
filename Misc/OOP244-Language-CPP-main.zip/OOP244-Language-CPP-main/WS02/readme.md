# Week 2 Workshop : Dynamic Memory

## Learning
- allocate and deallocate dynamic memory
- using overload functions
- using references
