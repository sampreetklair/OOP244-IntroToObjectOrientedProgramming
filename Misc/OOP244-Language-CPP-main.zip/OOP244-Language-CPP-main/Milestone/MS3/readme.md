# Milestone 3

## Completed Modules

### Patient Module
![relationship](https://github.com/jjaykim/OOP-Language_CPP/blob/main/Milestone/MS2/images/classes.png)
- Create an abstract IOAble patient class (the patient class is a derived class from IOAble).
- The patient class is responsible to encapsulate a general patient arriving at the hospital.
