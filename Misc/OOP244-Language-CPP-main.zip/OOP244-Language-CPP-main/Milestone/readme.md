 # Project: General Hospital Pre-Triage Application
 - Because of the pandemic and prevention of the spread of COVID19, hospitals need to screen the patients and separate those in need of COVID-test from others. This has to be done in an orderly fashion by letting the patients know what is the expected wait time and let them know when they can be admitted. 
 
 ## The goal is to update new modules every week to finally complete one project.
- [Milestone 1](https://github.com/jjaykim/OOP-Language_CPP/tree/main/Milestone/MS1)
- [Milestone 2](https://github.com/jjaykim/OOP-Language_CPP/tree/main/Milestone/MS2)
- [Milestone 3](https://github.com/jjaykim/OOP-Language_CPP/tree/main/Milestone/MS3)
- [Milestone 4](https://github.com/jjaykim/OOP244-Language-CPP/tree/main/Milestone/MS4)
- [Milestone 5](https://github.com/jjaykim/OOP244-Language-CPP/tree/main/Milestone/MS5)
