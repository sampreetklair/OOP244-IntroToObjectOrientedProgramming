# Milestone 2

## Completed Modules

### Menu Module
- Menu class encapsulates a menu and provides selection functionality for the caller program

### IOAble interface module
![relationship](https://github.com/jjaykim/OOP-Language_CPP/blob/main/Milestone/MS2/images/classes.png)
- This class is an interface and enforces input and output methods to its derived classes.
- The IOAble class has only 4 pure virtual functions and a virtual empty destructor.

