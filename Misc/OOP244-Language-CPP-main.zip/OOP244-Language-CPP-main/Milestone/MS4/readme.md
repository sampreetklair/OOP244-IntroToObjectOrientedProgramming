# Milestone 4

## Completed Modules
The two modules are created to calculate tickets and waiting time separately depending on the module.

### The CovidPatient module
- The CovidPatient class is publicly derived from the Patient class.

### The TriagePatient Module
- The TriagePatient class is publicly derived from the Patient class.
