# Milestone 5

## Completed PreTriage Modules
- This module creates a lineup of patients and issues tickets for them as they arrive at the hospital.
- Each patient in the lineup will be either a COVID Patient or a Triage Patient and will receive a ticket with a number that will be called when they are being admitted to either the COVID test centre or Triage Centre.
