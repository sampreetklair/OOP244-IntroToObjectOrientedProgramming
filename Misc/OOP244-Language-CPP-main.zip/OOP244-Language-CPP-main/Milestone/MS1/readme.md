# Milestone 1

## Completed Modules

### utils Module  
- getInt  : receives the integer input from the user  
- getcstr : receives the string input from the user
### Time Module  
- read and write time values  
- measure the passage of time by doing basic arithmetic operations
