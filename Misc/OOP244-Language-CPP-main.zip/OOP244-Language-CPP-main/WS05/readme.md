# Workshop 5: Member Operators, Helper functions

## Learning
- define and create  binary member operator
- define and create a type conversion operator
- define and a create unary member operator 
- define and create helper binary operator between classes
- define and create a helper operator between a primitive type and a class
