# OOP-Language_CPP

#### I have completed all the coding by myself and copied only the code provided by the professor to submit my assignment.

<hr>

> This is the URL to the basic code provided by the professor.
> 
> https://github.com/Seneca-244200/OOP-Workshops
